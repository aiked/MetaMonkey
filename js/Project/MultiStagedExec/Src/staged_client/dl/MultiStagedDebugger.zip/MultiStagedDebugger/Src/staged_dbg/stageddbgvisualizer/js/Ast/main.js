




var ast = window.Ast.DrawTreeWithOpt();
console.log( ast.domtree );

console.log( ast.src );

