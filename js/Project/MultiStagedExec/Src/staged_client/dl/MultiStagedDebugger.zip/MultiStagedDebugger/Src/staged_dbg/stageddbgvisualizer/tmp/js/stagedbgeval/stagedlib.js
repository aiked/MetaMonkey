// stagedlib.js
// Library for debugging spidermonkey staged code 
// Giannis Apostolidis
// March 2015.
//
